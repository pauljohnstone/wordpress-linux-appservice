<?php
class Azure_app_service_migration_S2S_Server_Init_Server {

    public static function init_server($params) {

		// Verify token
		$token = AASM_Common_Utils::verify_token();
		if (!$token) {
			AASM_Common_Utils::echo_status(false, 'Input token is invalid. Please regenerate the token and try again.');
			return;
		}

		/*$jwtToken = $_REQUEST['jsonWebTokenValue'];
		$body = Azure_app_service_migration_Server_Jwt_Handler::decode($jwtToken, $token);*/
		$body = $_REQUEST['jsonWebTokenValue'];

		// Set Max memory limit
		@ini_set('memory_limit', '-1');

		// Set maximum execution time
		@set_time_limit( 0 );

		// deactivate plugins and themes
		Azure_app_service_migration_Custom_Logger::logInfo(AASM_S2S_SERVICE_TYPE, 'Deactivating plugins and themes', true);
    	self::deactivate_plugins_and_themes();

		// Delete existing Database files
		Azure_app_service_migration_Custom_Logger::logInfo(AASM_S2S_SERVICE_TYPE, 'Clearing existing database sql files', true);
		AASM_Common_Utils::clear_directory_recursive(AASM_DATABASE_TEMP_DIR);
		
		// delete w3 total cache temporary files
		self::delete_file(ABSPATH . AASM_W3TC_ADVANCED_CACHE_PATH);
		self::delete_file(ABSPATH . AASM_W3TC_OBJECT_CACHE_PATH);
		self::delete_file(ABSPATH . AASM_W3TC_DB_PATH);
		
		wp_die();
    }
    
    private static function delete_file($filename) {
        if (file_exists($filename)) {
            unlink($filename);
        }
    }
    
    private static function deactivate_plugins_and_themes() {
        // Get the list of active plugins
        $active_plugins = (array) get_option('active_plugins', array());
    
        // Define the plugin to exclude
        $exclude_plugin = 'azure_app_service_migration/azure_app_service_migration.php';
    
        // Deactivate all plugins except the specified one
        foreach ($active_plugins as $plugin) {
            // Exclude the specified plugin
            if ($plugin !== $exclude_plugin) {
                deactivate_plugins($plugin);
            }
        }
    
        // Deactivate the active theme
        switch_theme(''); // An empty string deactivates the current theme
    }
}