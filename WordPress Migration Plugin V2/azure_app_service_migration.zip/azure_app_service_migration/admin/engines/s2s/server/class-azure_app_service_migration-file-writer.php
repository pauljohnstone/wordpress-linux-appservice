<?php
class Azure_app_service_migration_Server_File_Writer {

    public static function writeFile($params) {
		// Set Max memory limit
		@ini_set('memory_limit', '-1');

		// Set params
		if ( empty( $params )) {
			$params = stripslashes_deep( array_merge( $_GET, $_POST ) );
		}

		if ( !isset($_REQUEST['jsonWebTokenValue']) ) {
			AASM_Common_Utils::echo_status(false, 'Invalid request input.');
			return;
		}

		$token = AASM_Common_Utils::verify_token();
		if (!$token) {
			AASM_Common_Utils::echo_status(false, 'Token has expired. Please generate a new token and restart migration.');
			return;
		}

		// Verify token
		/*$jwtToken = $_REQUEST['jsonWebTokenValue'];
		$request_body = Azure_app_service_migration_Server_Jwt_Handler::decode($jwtToken, $token);
		if (!$request_body) {
			AASM_Common_Utils::echo_status(false, 'Could not decode the input request. Please regenerate token and try again');
			return;
		}*/
		$request_body = $_REQUEST['jsonWebTokenValue'];

		if ( !isset($request_body['fileOffset']) ||
			!isset($request_body['chunkFileContent']) ||
			!isset($request_body['targetFilePath']) ||
			!isset($request_body['isFirstChunk']) ) {
			AASM_Common_Utils::echo_status(false, 'Invalid request input.');
			return;
		}

		$file_offset = $request_body['fileOffset'];
		$chunk_file_content = stripslashes($request_body['chunkFileContent']);
		$target_file_path = ABSPATH . $request_body['targetFilePath'];
		$is_first_chunk = $request_body['isFirstChunk'];

		// Create base directory of file if doesn't exist
		if (!is_dir(dirname($target_file_path))) {
			mkdir(dirname($target_file_path), 0755, true);
		}

		// Open target file
		$file_handle = @fopen( $target_file_path, $is_first_chunk ? 'wb' : 'r+b' );

		// return false if could not open file
		if ( $file_handle === false ) {
			AASM_Common_Utils::echo_status(false, 'Unable to open file for writing. File: ' . $target_file_path);
			return;
		}

		// seek to offset
		self::set_file_pointer($file_handle, $file_offset, $target_file_path);

		// write chunk file content to target file
		if ( ( $file_bytes = @fwrite( $file_handle, $chunk_file_content ) ) !== false ) {
			if ( strlen( $chunk_file_content ) !== $file_bytes ) {
				AASM_Common_Utils::echo_status(false, 'Out of disk space. Unable to write content to file. File: ' . $target_file_path);
				return;
			}
		}

		// return success message
		AASM_Common_Utils::echo_status(true, 'File written successfully.');

		fclose($file_handle);
    }

	public static function writeFileBatch($params) {
		// Set Max memory limit
		@ini_set('memory_limit', '-1');

		// Set params
		if ( empty( $params )) {
			$params = stripslashes_deep( array_merge( $_GET, $_POST ) );
		}

		if ( !isset($_REQUEST['jsonWebTokenValue']) ) {
			AASM_Common_Utils::echo_status(false, 'Invalid request input.');
			return;
		}

		// Verify token
		$token = AASM_Common_Utils::verify_token();
		if (!$token) {
			AASM_Common_Utils::echo_status(false, 'Token has expired. Please generate a new token and restart migration.');
			return;
		}

		// Decode JWT token
		/*$jwtToken = $_REQUEST['jsonWebTokenValue'];
		$request_body = Azure_app_service_migration_Server_Jwt_Handler::decode($jwtToken, $token);
		if (!$request_body) {
			AASM_Common_Utils::echo_status(false, 'Could not decode the input request. Please regenerate token and try again');
			return;
		}*/

		$request_body = $_REQUEST['jsonWebTokenValue'];

		$file_list = $request_body['fileList'];
		for ($i = 0; $i < count($file_list); $i++) {
			if ( !isset($file_list[$i]['fileOffset']) ||
				!isset($file_list[$i]['chunkFileContent']) ||
				!isset($file_list[$i]['targetFilePath']) ||
				!isset($file_list[$i]['isFirstChunk']) ) {
					AASM_Common_Utils::echo_status(false, 'Invalid request input.');
					return;
			}

			$file_offset = $file_list[$i]['fileOffset'];
			$chunk_file_content = stripslashes($file_list[$i]['chunkFileContent']);
			$target_file_path = ABSPATH . $file_list[$i]['targetFilePath'];
			$is_first_chunk = $file_list[$i]['isFirstChunk'];

			// Create base directory of file if doesn't exist
			if (!is_dir(dirname($target_file_path))) {
				mkdir(dirname($target_file_path), 0755, true);
			}

			// Open target file
			$file_handle = @fopen( $target_file_path, $is_first_chunk ? 'wb' : 'r+b' );

			// return false if could not open file
			if ( $file_handle === false ) {
				AASM_Common_Utils::echo_status(false, 'Unable to open file for writing. File: ' . $target_file_path);
				return;
			}

			// seek to offset
			self::set_file_pointer($file_handle, $file_offset, $target_file_path);

			// write chunk file content to target file
			if ( ( $file_bytes = @fwrite( $file_handle, $chunk_file_content ) ) !== false ) {
				if ( strlen( $chunk_file_content ) !== $file_bytes ) {
					AASM_Common_Utils::echo_status(false, 'Out of disk space. Unable to write content to file. File: ' . $target_file_path);
					return;
				}
			}

			fclose($file_handle);
		}
    }

	private static function set_file_pointer( $file_handle, $offset, $file_name ) {
		if ( @fseek( $file_handle, $offset, SEEK_SET ) === -1 ) {
			AASM_Common_Utils::echo_status('false', 'Unable to seek to offset of file. File: ' . $file_name . ' Offset: ' . $offset);
			wp_die();
		}
	}
}