<?php
class Azure_app_service_migration_S2S_Client_Migrate {
    public static function migrate( $params )
    {
        try {
            $password = isset($params['confpassword']) ? $params['confpassword'] : "";
            $dontexptpostrevisions = isset($params['dontexptpostrevisions']) ? $params['dontexptpostrevisions'] : "";
            $dontexptsmedialibrary = isset($params['dontexptsmedialibrary']) ? $params['dontexptsmedialibrary'] : "";
            $dontexptsthems = isset($params['dontexptsthems']) ? $params['dontexptsthems'] : "";
            $dontexptmustuseplugins = isset($params['dontexptmustuseplugs']) ? $params['dontexptmustuseplugs'] : "";
            $dontexptplugins = isset($params['dontexptplugins']) ? $params['dontexptplugins'] : "";
            $dontdbsql = isset($params['donotdbsql']) ? $params['donotdbsql'] : "";
            $destinationSiteUrl = isset($params['destination_site_url']) ? $params['destination_site_url'] : "";
            $destinationSiteToken = isset($params['destination_site_token']) ? $params['destination_site_token'] : "";
            $params['chunk_size'] = isset($params['chunk_size']) ? intval($params['chunk_size']) : 5000000;
            $params['server_timeout'] = isset($params['server_timeout']) ? intval($params['server_timeout']) : 60;
            $params['chunk_file_count'] = 1000;

            if (isset($params['s2s']) && $params['s2s']) {
                // TODO: Check for auth token as well
                if (!isset($params['destination_site_url']) || !isset($params['destination_site_token']) || empty($params['destination_site_token'])) {
                    throw new Exception('Please provide destination site url and token.');
                }
            }

            if (!isset($params['status'])) {
                $params['status'] = array();
            }

            // Enumerate wp-content directory into a csv file
            if (!isset($params['status']['enumerate_content']) || !$params['status']['enumerate_content']) {
                try {
                    $enumerate_result = Azure_app_service_migration_Content_Enumerator::enumerate_content($params, AASM_S2S_SERVICE_TYPE);
                } catch (Exception $ex) {
                    throw $ex;
                }

                if ($enumerate_result['completed']) {
                    unset($params['enumerate_start_index']);
                    $params['status']['enumerate_content'] = true;
                } else {
                    $params['enumerate_start_index'] = $enumerate_result['enumerate_start_index'];
                }

                // start new session to continue rest of migration
                $params['completed'] = false;
                return $params;
            }

            if (!isset($params['status']['parse_enumerate_file']) || !$params['status']['parse_enumerate_file']) {
                try {
                    // Parse enumerate file
                    if (!Azure_app_service_migration_Enumerate_File_Parser::send_files($params)) {
                        $params['completed'] = false;
                        return $params;
                    }
                } catch ( Exception $ex ) {
                    throw $ex;
                }

                // start new session to continue rest of migration
                $params['status']['parse_enumerate_file'] = true;
                $params['completed'] = false;
                return $params;
            }

            // Generate Database Dump files
            if (!isset($params['status']['export_database_tables']) || !$params['status']['export_database_tables']) {
                $params['status']['export_database_tables'] = false;

                if (!Azure_app_service_migration_Export_Database::exportDatabaseTables($params, $dontexptpostrevisions)) {
                    return $params;
                }

                $params['completed'] = false;
                $params['status']['export_database_tables'] = true;
                return $params;
            }

            // Send database import request to destination server
            self::sendAsyncPostHttpCall($params, $destinationSiteUrl);

            // return completed
            $params['priority'] = 20;
            $params['completed'] = true;
            return $params;
        } catch (Exception $e) {
            Azure_app_service_migration_Custom_Logger::logError(AASM_S2S_SERVICE_TYPE, 'An exception occurred: ' . $e->getMessage());
            echo json_encode(array(
                "status" => 0,
                "message" => "An exception occurred: " . $e->getMessage(),
            ));
            throw $e;
        }
        return $params;
    }

    private static function sendAsyncPostHttpCall(&$params, $destinationSiteUrl) {
        Azure_app_service_migration_Custom_Logger::logInfo(AASM_S2S_SERVICE_TYPE, 'Triggering Database import on destination site.', true);
        
        // Initialize parameters for import request to destination server
        $body_data = array();
        
        // setting priority parameter to 20 will trigger database-import 
        // when request made to destination server
        $body_data['priority'] = 20;
        $body_data['is_first_request'] = true;
        $body_data['is_s2s_migration'] = true;
        $body_data['retain_w3tc_config'] = isset($params['retain_w3tc_config']) ? $params['retain_w3tc_config'] : false;

        // Import http request to destination server
        $response = wp_remote_post(                                                                                                        
            $destinationSiteUrl . 'wp-admin/admin-ajax.php?action=aasm_import' ,
            array(
            'method'    => 'POST',
            'timeout'   => 5,
            'blocking'  => false,
            'sslverify' => false,
            'headers'   => AASM_Common_Utils::http_export_headers(array()),
            'body'      => $body_data,
            'cookies'   => array(),
            )                                           
        );
    }
}