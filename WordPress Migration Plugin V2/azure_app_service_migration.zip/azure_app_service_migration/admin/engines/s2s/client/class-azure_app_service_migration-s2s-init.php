<?php
class Azure_app_service_migration_S2S_Client_Init_Server {
    public static function execute( $params )
    {
        if (!isset($params['destination_site_url']) || !isset($params['destination_site_token']) || empty($params['destination_site_token'])) {
            throw new Exception('Please provide destination site url and token.');
        }

        // initalize inputs
        $destinationSiteUrl = $params['destination_site_url'];
        $destinationSiteToken = $params['destination_site_token'];

        // INitialize body data
        $body_data = array();
        //$body_data['jsonWebTokenValue'] = Azure_app_service_migration_Server_Jwt_Handler::encode($destinationSiteToken, array());
        $body_data['jsonWebTokenValue'] = array();

        $response = wp_remote_post(
            $destinationSiteUrl . 'wp-admin/admin-ajax.php?action=aasm_s2s_init_destination_site',
            array(
                'method'    => 'POST',
                'timeout'   => 25,
                'blocking'  => true,
                'sslverify' => false,
                'headers'   => AASM_Common_Utils::http_export_headers(array()),
                'body'      => $body_data,
                'cookies'   => array(),
            )
        );

        // Check for response error
        if (is_wp_error($response)) {
            throw new Exception($response->get_error_message());
        }

        // Check the HTTP response code
        $response_code = wp_remote_retrieve_response_code($response);
        if ($response_code === 200) {
            // Update parameters to start next S2S migration function
            $params['completed'] = true;
            $params['priority'] = 10;
            
            return $params;
        } else {
            throw new Exception ('Error: Received HTTP Response Code: ' . $response_code);
        }

        return $params;
    }
}