<?php
class Azure_app_service_migration_Export_FileBackupHandler
{
    public static function handle_wp_filebackup($params)
    {
        try {
            $param = isset($_REQUEST['param']) ? $_REQUEST['param'] : "";
            if (!empty($param)) {
                if ($param == "wp_filebackup") {
                    $password = isset($params['confpassword']) ? $params['confpassword'] : "";
                    $dontexptpostrevisions = isset($params['dontexptpostrevisions']) ? $params['dontexptpostrevisions'] : "";
                    $dontexptsmedialibrary = isset($params['dontexptsmedialibrary']) ? $params['dontexptsmedialibrary'] : "";
                    $dontexptsthems = isset($params['dontexptsthems']) ? $params['dontexptsthems'] : "";
                    $dontexptmustuseplugins = isset($params['dontexptmustuseplugs']) ? $params['dontexptmustuseplugs'] : "";
                    $dontexptplugins = isset($params['dontexptplugins']) ? $params['dontexptplugins'] : "";
                    $dontdbsql = isset($params['donotdbsql']) ? $params['donotdbsql'] : "";

                    if (isset($params['s2s']) && $params['s2s']) {
                        // TODO: Check for auth token as well
                        if (!isset($params['destination_site_url'])) {
                            throw new Exception('Please provide destination site url and retry.');
                        }
                    }

                    if (!isset($params['status'])) {
                        $params['status'] = array();
                    }

                    $zipFilePath = self::getZipFilePath($params['zip_file_name']);
                    //Azure_app_service_migration_Custom_Logger::logInfo(AASM_EXPORT_SERVICE_TYPE, 'Zip file path is: ' . $zipFilePath);

                    $excludedFolders = self::getExcludedFolders($dontexptsmedialibrary, $dontexptsthems, $dontexptmustuseplugins, $dontexptplugins);

                    // Enumerate wp-content directory into a csv file
                    if (!isset($params['status']['enumerate_content']) || !$params['status']['enumerate_content']) {
                        try {
                            $enumerate_result = Azure_app_service_migration_Content_Enumerator::enumerate_content($params, AASM_EXPORT_SERVICE_TYPE);
                        } catch (Exception $ex) {
                            throw $ex;
                        }

                        if ($enumerate_result['completed']) {
                            // Throw exception if export file size exceeds 4GB
                            if ($params['export_filesize'] > AASM_EXPORT_MAX_FILE_SIZE) {
                                throw new Exception('Error: Export file size exceeds 4GB.');
                            }

                            // Throw exception if number of files exceeds 65k
                            if ($params['export_num_files'] > AASM_ZIP_MAX_NUM_FILES) {
                                throw new Exception('Error: Number of files to export exceeds 65k.');
                            }

                            unset($params['enumerate_start_index']);
                            $params['status']['enumerate_content'] = true;
                        } else {
                            $params['enumerate_start_index'] = $enumerate_result['enumerate_start_index'];
                        }

                        // start new session to continue rest of export
                        $params['completed'] = false;
                        return $params;
                    }

                    // Generate Zip Archive
                    $zipCreated = false;
                    try {
                        $zipCreated = self::createZipArchive($zipFilePath, $excludedFolders, $dontdbsql, $password, $dontexptpostrevisions, $params);
                    } catch (Exception $ex) {
                        throw $ex;
                    }

                    if ($zipCreated) {
                        Azure_app_service_migration_Custom_Logger::logInfo(AASM_EXPORT_SERVICE_TYPE, 'Content is exported and Ready to download');
                        unset($params['status']);
                        $params['completed'] = true;
                        return $params;
                    } else {
                        $params['completed'] = false;
                        return $params;
                    }
                }
            }
        } catch (Exception $e) {
            Azure_app_service_migration_Custom_Logger::logError(AASM_EXPORT_SERVICE_TYPE, 'An exception occurred: ' . $e->getMessage());
            echo json_encode(array(
                "status" => 0,
                "message" => "An exception occurred: " . $e->getMessage(),
            ));
            throw $e;
        }
        return $params;
    }

    public static function generateZipFileName()
    {
        $File_Name = $_SERVER['HTTP_HOST'];
        $datetime = date('Y-m-d_H-i-s');
        return $File_Name . '_' . $datetime . '.zip';
    }

    private static function getZipFilePath($zipFileName)
    {
        // Create the directory if it doesn't exist
        if (!is_dir(AASM_EXPORT_ZIP_LOCATION)) {
            mkdir(AASM_EXPORT_ZIP_LOCATION, 0777, true);
            // Set appropriate permissions for the directory (0777 allows read, write, and execute permissions for everyone)
        }
        return AASM_EXPORT_ZIP_LOCATION . $zipFileName;
    }

    private static function getExcludedFolders($dontexptsmedialibrary, $dontexptsthems, $dontexptmustuseplugins, $dontexptplugins)
    {
        $excludedFolders = [];
        if ($dontexptsmedialibrary) {
            $excludedFolders[] = 'uploads';
        }
        if ($dontexptsthems) {
            $excludedFolders[] = 'themes';
        }
        if ($dontexptmustuseplugins) {
            $excludedFolders[] = 'mu-plugins';
        }
        if ($dontexptplugins) {
            $excludedFolders[] = 'plugins';
        }

        // Exclude AASM plugin from export
        $excludedFolders[] = AASM_PLUGIN_RELATIVE_PATH;
        $excludedFolders[] = AASM_DEBUG_LOG_PATH;
        
        return $excludedFolders;
    }

    public static function deleteExistingZipFiles()
    {
        try {
            // Return if export storage directory not present
            if (!is_dir(AASM_EXPORT_ZIP_LOCATION)) {
                return;
            }

            $File_Name = $_SERVER['HTTP_HOST'];
            $iterator = new DirectoryIterator(AASM_EXPORT_ZIP_LOCATION);
            foreach ($iterator as $file) {
                if ($file->isFile() && strpos($file->getFilename(), $File_Name) === 0 && pathinfo($file->getFilename(), PATHINFO_EXTENSION) === 'zip') {
                    $filePath = $file->getPathname();
                    unlink($filePath);
                }
            }
        } catch (Exception $e) {
            Azure_app_service_migration_Custom_Logger::logError(AASM_EXPORT_SERVICE_TYPE, 'File Delete error: ' . $e->getMessage());
            throw new AASM_File_Delete_Exception('File Delete error:' . $e->getMessage());
        }
    }

    private static function createZipArchive($zipFilePath, $excludedFolders, $dontdbsql, $password, $dontexptpostrevisions, &$params)
    {
        if (!isset($params['status']['create_zip_archive'])) {
            $params['status']['create_zip_archive'] = false;
        }

        // Return if zip archive was already created in previous sessions
        if ($params['status']['create_zip_archive']) {
            return true;
        }

        $zipCreated = false;
        try {
                $zip = new ZipArchive();
                if ($zip->open($zipFilePath, ZipArchive::CREATE) === true) {
                    $wpContentFolderNameInZip = 'wp-content/';
                    $zip->addEmptyDir($wpContentFolderNameInZip);
                    if (!$dontdbsql) {
                        $wpDBFolderNameInZip = 'wp-database/';
                        $zip->addEmptyDir($wpDBFolderNameInZip);
                        
                        // Export Database Tables
                        if (!Azure_app_service_migration_Export_Database::exportDatabaseTables($params, $dontexptpostrevisions, $zip, $password)) {
                            return false;
                        }
                    }

                    $wp_root_path = get_home_path();
                    $folderPath = $wp_root_path . '/wp-content/';

                    try {
                        // Parse enumerate file and add constituent files to zip
                        if (!Azure_app_service_migration_Enumerate_File_Parser::parse_enumerate_file($params, $zip, $password)) {
                            $zip->close();
                            return false;
                        }
                    } catch ( Exception $ex ) {
                        throw $ex;
                    }

                    $zip->close();
                    Azure_app_service_migration_Custom_Logger::logInfo(AASM_EXPORT_SERVICE_TYPE, 'Zip Archive closed successfully.');

                    return true;
                } else {
                    throw new Exception("Export failed... Couldn't open the Zip file: " . $zipFilePath);
                }
        } catch (Exception $e) {
            Azure_app_service_migration_Custom_Logger::logError(AASM_EXPORT_SERVICE_TYPE, 'Zip creation error: ' . $e->getMessage());
            throw new AASM_Archive_Exception('Zip creation error:' . $e->getMessage());
        }
        return false;
    }

    private static function filterCallback($current, $excludedFolders, &$filteredElements)
    {
        $fileName = $current->getFilename();
        $filePath = $current->getPathname();
        $relativePath = substr($filePath, strlen(get_home_path()));
        $relativePath = str_replace('\\', '/', $relativePath);
        $relativePathParts = explode('/', $relativePath);
        $parentFolder = isset($relativePathParts[2]) ? $relativePathParts[2] : '';

        if ($fileName == "." || $fileName == "..") {
            return false;
        }

        if (in_array($parentFolder, $excludedFolders)) {
            return false;
        }

        if (in_array($relativePath, $filteredElements)) {
            return false;
        }

        $filteredElements[] = $relativePath;
        return true;
    }
}
?>