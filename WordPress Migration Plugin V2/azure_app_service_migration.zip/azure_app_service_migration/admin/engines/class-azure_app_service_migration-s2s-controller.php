<?php
class Azure_app_service_migration_S2S_Controller {

    public static function s2s_migrate($params) {

		// Continue execution when user aborts
		@ignore_user_abort( true );

		// Set maximum execution time
		@set_time_limit( 0 );

		// Set maximum time in seconds a script is allowed to parse input data
		@ini_set( 'max_input_time', '-1' );

		// Set maximum backtracking steps
		@ini_set( 'pcre.backtrack_limit', PHP_INT_MAX );

		// Set Max memory limit
		@ini_set('memory_limit', '-1');

		// Set params
		if ( empty( $params ) ) {
			$params = stripslashes_deep( array_merge( $_GET, $_POST ) );
		}

		// Set priority
		if ( ! isset( $params['priority'] ) ) {
			$params['priority'] = 5;
		}

		// Verify destination site url
		if (isset( $params['destination_site_url']) && !(substr($params['destination_site_url'], -1) === '/' ) ) {
			Azure_app_service_migration_Custom_Logger::logError(AASM_S2S_SERVICE_TYPE, 'Invalid Destination Site URL. Please ensure it is of the format: https://mywpapp.com/');
		}

		if (isset($params['is_first_request']) && !$params['is_first_request']) {
			Azure_app_service_migration_Custom_Logger::logInfo(AASM_S2S_SERVICE_TYPE, 'Starting a new HTTP session.', true);
		}

		// below code is executed only on the first http request
		if ( isset($params['is_first_request']) && $params['is_first_request']) {
			// Validate site compatibility
			self::validate_site_compatibility();

			// Initialize s2s cancel file
			file_put_contents(AASM_S2S_CANCEL_FILE_PATH, '0');

			// initalize import log file
			Azure_app_service_migration_Custom_Logger::delete_log_file(AASM_S2S_SERVICE_TYPE);
			Azure_app_service_migration_Custom_Logger::init(AASM_S2S_SERVICE_TYPE);
			Azure_app_service_migration_Custom_Logger::logInfo(AASM_S2S_SERVICE_TYPE, 'Starting Server-Server Migration to ' . $params['destination_site_url'] . '.', true);

			//initialize status file
			AASM_Common_Utils::initialize_status_file(AASM_S2S_SERVICE_TYPE);

			// delete enumerate file if already exists
			if (is_file(AASM_ENUMERATE_FILE)) {
				unlink(AASM_ENUMERATE_FILE);
			}
			mkdir(dirname(AASM_ENUMERATE_FILE), 0755, true);

			// clear DB temp directory
			AASM_Common_Utils::clear_directory_recursive(AASM_S2S_DB_LOCATION);

			// parameter to identify s2s migration
			$params['s2s'] = true;

			// clear DB temp directory
			//AASM_Common_Utils::clear_directory_recursive(AASM_DATABASE_TEMP_DIR);

			// Initialize chunk size param
			$params['chunk_size'] = isset($params['chunk_size']) ? intval($params['chunk_size']) * 1000 : 5000000;

			// clear is_first_request param
			unset($params['is_first_request']);
		}

		self::check_cancel_status();

		$params['completed'] = false;

		// Loop over filters
		if ( ( $filters = AASM_Common_Utils::get_filter_callbacks( 'aasm_s2s' ) ) ) {
			while ( $hooks = current( $filters ) ) {
				if ( intval( $params['priority'] ) === key( $filters ) ) {
					foreach ( $hooks as $hook ) {
						try {
							// Run function hook
							$params = call_user_func_array( $hook['function'], array( $params ) );
						} catch ( Exception $e ) {
							Azure_app_service_migration_Custom_Logger::handleException($e);
							exit;
						}
					}

					// exit after S2S migration is complete
					if ($params['priority'] == 20 && $params['completed']) {
						Azure_app_service_migration_Custom_Logger::done(AASM_S2S_SERVICE_TYPE);
						exit;
					}

					$response = wp_remote_post(                                                                                                        
						admin_url( 'admin-ajax.php?action=aasm_s2s' ) ,
						array(                                               
						'method'    => 'POST',
						'timeout'   => 5,                                        
						'blocking'  => false,
						'sslverify' => false,
						'headers'   => AASM_Common_Utils::http_export_headers(array()),                                             
						'body'      => $params,
						'cookies'   => array(),
						)
					);
					exit;
				}
				next( $filters );
			}
		}
    }

	private static function check_cancel_status() {
		if (file_exists(AASM_S2S_CANCEL_FILE_PATH)) {
			// Retrieve the content of the file
			$content = file_get_contents(AASM_S2S_CANCEL_FILE_PATH);
		
			// Check if the content is exactly '1'
			if ($content === '1') {
				Azure_app_service_migration_Custom_Logger::logInfo(AASM_S2S_SERVICE_TYPE, 'Server-Server migration cancelled.');
				wp_die();
			}
		}
	}

	private static function validate_site_compatibility() {
		// Check MySQL database version
		global $wpdb;
		$mysql_version = $wpdb->db_version();
	
		if (version_compare($mysql_version, '5.7', '<')) {
			// Display an admin notice or handle the version mismatch in a way that makes sense for your plugin
			Azure_app_service_migration_Custom_Logger::handleException(new Exception('Your MySQL version is too old. Please upgrade to at least MySQL 5.7.'));
		}
	
		// Check PHP version
		$php_version = phpversion();
	
		if (version_compare($php_version, '7.0', '<')) {
			// Display an admin notice or handle the version mismatch in a way that makes sense for your plugin
			Azure_app_service_migration_Custom_Logger::handleException(new Exception('Your PHP version is too old. Please upgrade to at least PHP 7.0.'));
		}
	}

	public static function s2s_cancel() {
		file_put_contents(AASM_S2S_CANCEL_FILE_PATH, '1');
		wp_die();
	}
}