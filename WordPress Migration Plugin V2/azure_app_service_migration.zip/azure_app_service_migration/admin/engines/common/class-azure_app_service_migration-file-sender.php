<?php
class Azure_app_service_migration_File_Sender {
    public static function send_file(&$params, $start_time, $source_file_path, $target_file_path) {
        if (!isset($params['destination_site_token']) || empty($params['destination_site_token'])) {
            return false;
        }

        if (!isset($params['send_file_params'])) {
            $params['send_file_params'] = array();
        }

        // Initialize file offset parameter
        if (!isset($params['send_file_params']['file_offset'])) {
            $params['send_file_params']['file_offset'] = 0;
        }
        $file_offset = $params['send_file_params']['file_offset'];

        // define chunk size ~5MB
        $chunk_size = 5000000;

        while (true) {
            // Return if timeout exceeded
            if (microtime(true) - $start_time > 10) {
                $params['send_file_params']['file_offset'] = $file_offset;
                return false;
            }

            // get $chunk_size bytes file content beginning from $file_offset
            try {
                $file_content_result = self::get_file_content_from_offset($source_file_path, $file_offset, $chunk_size);
            } catch(Exception $ex) {
                throw $ex;
            }

            // validate file content
            $file_content = $file_content_result['file_content'];
            if ($file_content === false) {
                throw new Exception ('Could not read the file : ' . $source_file_path);
            }

            try {
                self::send_file_to_destination_server(
                    $params['destination_site_url'],
                    $file_content,
                    $file_offset === 0,
                    $target_file_path,
                    $file_offset,
                    $params['destination_site_token'],
                    $params['server_timeout']
                );
            } catch (Exception $ex) {
                throw $ex;
            }

            $file_offset += $chunk_size;
            if ($file_content_result['is_feof']) {
                unset($params['send_file_params']);
                return true;
            }
        }

        $params['send_file_params']['file_offset'] = $file_offset;
        return false;
    }

    public static function send_file_batch($file_list, $server_url, $token, $timeout) {
        $body_data = array(
            'fileList' => $file_list
        );

        // INitialize body data
        $body = array();
        //$body['jsonWebTokenValue'] = Azure_app_service_migration_Server_Jwt_Handler::encode($token, $body_data);
        $body['jsonWebTokenValue'] = $body_data;

        $response = wp_remote_post(
            $server_url . 'wp-admin/admin-ajax.php?action=aasm_write_file_batch',
            array(
                'method'    => 'POST',
                'timeout'   => $timeout,
                'blocking'  => true,
                'sslverify' => false,
                'body'      => $body,
                'cookies'   => array(),
            )
        );

        // Check for response error
        if (is_wp_error($response)) {
            return false;
        }

        // Check the HTTP response code
        $response_code = wp_remote_retrieve_response_code($response);
        if ($response_code === 200) {
            return true;
        }
        return false;
    }

    private static function get_file_content_from_offset($file_path, $offset, $content_size) {
        // Initialize file content
        $file_content = false;

        // open target file
        $file = fopen($file_path, 'r');

        // Seek to offset
        if ( @fseek( $file, $offset, SEEK_SET ) === -1 ) {
			throw new Exception('Error sending db file: Unable to seek to offset of file. File: ' . $file_path . ' Offset: ' . $offset);
		}
        
        // read file
        if ( !$file ) {
            throw new Exception('Could not read file : ' . $file_path);
        }

        $file_content = fread($file, $content_size);
        $is_feof = feof($file);

        // close file
        fclose($file);

        return array(
            'is_feof' => $is_feof,
            'file_content' => $file_content
        );
    }

    // Sends chunk file content to destination server
    private static function send_file_to_destination_server($server_url, $chunk_file_content, $is_first_chunk, $target_file_path, $file_offset, $token, $timeout) {

        // Initialize request body data
        $body_data = array(
            'chunkFileContent' => $chunk_file_content,
            'isFirstChunk' => $is_first_chunk,
            'targetFilePath' => $target_file_path,
            'fileOffset' => $file_offset,
        );

        // INitialize body data
        $body = array();
        //$body['jsonWebTokenValue'] = Azure_app_service_migration_Server_Jwt_Handler::encode($destinationSiteToken, $body_data);
        $body['jsonWebTokenValue'] = $body_data;

        $response = wp_remote_post(
            $server_url . 'wp-admin/admin-ajax.php?action=aasm_write_file',
            array(
            'method'    => 'POST',
            'timeout'   => $timeout,
            'blocking'  => true,
            'sslverify' => false,
            'body'      => $body,
            'cookies'   => array(),
            )
        );

        // Check for response error
        if (is_wp_error($response)) {
            throw new Exception($response->get_error_message());
        }

        // Check the HTTP response code
        $response_code = wp_remote_retrieve_response_code($response);
        if ($response_code === 200) {
            return true;
        } else {
            throw new Exception ('Error: Received HTTP Response Code: ' . $response_code);
        }
    }
}