<?php
class Azure_app_service_migration_Export_Database {
    public static function exportDatabaseTables(&$params, $dontexptpostrevisions, $zip = null, $password = '' ) {
        $service_type = $zip 
                        ? AASM_EXPORT_SERVICE_TYPE
                        : AASM_S2S_SERVICE_TYPE;

        // Export database tables' structure if not completed in previous sessions
        if (!isset($params['status']['export_database_table_structure']) || !$params['status']['export_database_table_structure']) {
            // Log database table structure export status first time
            if (!isset($params['status']['export_database_table_structure'])) {
                Azure_app_service_migration_Custom_Logger::logInfo($service_type, 'Exporting Database table schema.');
            }

            $params['status']['export_database_table_structure'] = false;
            if (self::exportDatabaseTablesStructure($params, $dontexptpostrevisions, $service_type, $zip, $password)) {
                $params['status']['export_database_table_structure'] = true;
            }
            // return false to start a new session which will resume export database records
            return false;
        }

        // Export database tables' records if not completed in previous sessions
        if (!isset($params['status']['export_database_table_records']) || !$params['status']['export_database_table_records']) {
            // Log database table records export status first time
            if (!isset($params['status']['export_database_table_records'])) {
                Azure_app_service_migration_Custom_Logger::logInfo($service_type, 'Exporting Database table records.');
            }
            
            $params['status']['export_database_table_records'] = false;
            if (self::exportDatabaseTablesRecords($params, $dontexptpostrevisions, $service_type, $zip, $password)) {
                $params['status']['export_database_table_records'] = true;
            }
            // return false to start a new session which will resume zipping of wp-content
            return false;
        }

        // Transfer DB files to destination server for Server to Server migration
        if (!$zip) {
            return self::send_db_files($params, $service_type);
        }

        return true;
    }

    private static function exportDatabaseTablesStructure(&$params, $dontexptpostrevisions, $service_type, $zip, $password)
    {
        // Start time
		$start = microtime( true );

        // Initialize completed flag
        $completed = true;

        $wpDBFolderNameInZip = AASM_DATABASE_RELATIVE_PATH_IN_ZIP;

        // Initialize start table index
        if (!isset($params['start_db_table_structure_index'])) {
            $params['start_db_table_structure_index'] = 0;
        }
        $start_table_index = $params['start_db_table_structure_index'];

        global $wpdb;
        $tablesQuery = "SHOW TABLES";
        $tables = $wpdb->get_results($tablesQuery, ARRAY_N);

        try {
            for ($tableNum = $start_table_index; $tableNum < count($tables); $tableNum++) {
                if ( ( microtime( true ) - $start ) > 20 ) {
                    $params['start_db_table_structure_index'] = $tableNum;
                    $completed = false;
                }
                $tableName = $tables[$tableNum][0];
                $structureQuery = "SHOW CREATE TABLE {$tableName}";
                $structureResult = $wpdb->get_row($structureQuery, ARRAY_N);
                $tableStructure = $structureResult[1];
                $structureFilename = "{$tableName}_structure.sql";
                if ($zip) {
                    $zip->addFromString($wpDBFolderNameInZip . $structureFilename, $tableStructure);

                    if ($password !== '') {
                        $zip->setEncryptionName($wpDBFolderNameInZip . $structureFilename, ZipArchive::EM_AES_256, $password);
                    }
                } else {
                    $local_db_file_path = AASM_S2S_DB_LOCATION . $structureFilename;
                    self::save_db_file($local_db_file_path, $tableStructure, true);
                }
            }
            
            // return false if not completed to resume execution in a new session
            if (!$completed) {
                return false;
            } else {
                unset($params['start_db_table_structure_index']);
                return true;
            }
        } catch (Exception $e) {
            Azure_app_service_migration_Custom_Logger::logError($service_type, 'DB Tables export exception: ' . $e->getMessage());
            throw new AASM_Export_Exception('DB Tables export exception:' . $e->getMessage());
        }
        
        return $completed;
    }

    private static function exportDatabaseTablesRecords(&$params, $dontexptpostrevisions, $service_type, $zip, $password)
    {
        // Start time
		$start = microtime( true );

        // initialize completed flag
        $completed = true;

        $wpDBFolderNameInZip = AASM_DATABASE_RELATIVE_PATH_IN_ZIP;

        // Initialize start table index
        if (!isset($params['start_db_table_records_index'])) {
            $params['start_db_table_records_index'] = 0;
        }
        $start_table_index = $params['start_db_table_records_index'];

        // Initialize db records offset
        if (!isset($params['db_records_offset'])) {
            $params['db_records_offset'] = 0;
        }
        $offset = $params['db_records_offset'];

        // Initialize db records batchNumber
        if (!isset($params['db_records_batchNumber'])) {
            $params['db_records_batchNumber'] = 0;
        }
        $batchNumber = $params['db_records_batchNumber'];

        $batchSize = 1000;

        global $wpdb;
        $tablesQuery = "SHOW TABLES";
        $tables = $wpdb->get_results($tablesQuery, ARRAY_N);

        try {
            for ($tableNum = $start_table_index; $tableNum < count($tables); $tableNum++) {
                // break when timeout (20s) is reached
                if ( ( microtime( true ) - $start ) > 10 ) {
                    $params['start_db_table_records_index'] = $tableNum;
                    $params['db_records_offset'] = $offset;
                    $params['db_records_batchNumber'] = $batchNumber;
                    $completed = false;
                    break;
                }

                $tableName = $tables[$tableNum][0];
                Azure_app_service_migration_Custom_Logger::logInfo($service_type, 'Exporting Records for table : ' . $tableName . '-started');       
                do {
                    if ($dontexptpostrevisions && $tableName == 'wp_posts') {
                        $recordsQuery = "SELECT * FROM {$tableName} WHERE post_type != 'revision' LIMIT {$offset}, {$batchSize}";
                    } else {
                        $recordsQuery = "SELECT * FROM {$tableName} LIMIT {$offset}, {$batchSize}";
                    }

                    $records = $wpdb->get_results($recordsQuery, ARRAY_A);
                    $recordsFilename = "{$tableName}_records_batch{$batchNumber}.sql";

                    if (!empty($records)) {
                        $recordsContent = "";

                        foreach ($records as $record) {
                            $recordValues = [];

                            foreach ($record as $value) {
                                $recordValues[] = self::formatRecordValue($value);
                            }

                            $recordsContent .= "INSERT INTO {$tableName} VALUES (" . implode(', ', $recordValues) . ");\n";
                        }

                        if ($zip) {
                            $zip->addFromString($wpDBFolderNameInZip . $recordsFilename, $recordsContent);

                            if ($password !== '') {
                                $zip->setEncryptionName($wpDBFolderNameInZip . $recordsFilename, ZipArchive::EM_AES_256, $password);
                            }
                        } else {
                            $local_db_file_path = AASM_S2S_DB_LOCATION . $recordsFilename;
                            self::save_db_file($local_db_file_path, $recordsContent, $batchNumber == 0);
                        }
                    }

                    $offset += $batchSize;
                    $batchNumber++;
                } while (!empty($records));

                $batchNumber = 0;
                $offset = 0;

                Azure_app_service_migration_Custom_Logger::logInfo($service_type, 'Exporting Records for table: ' . $tableName . ' - completed');
            }

            if (!$completed) {
                return false;
            } else {
                unset($params['start_db_table_records_index']);
                unset($params['db_records_offset']);
                unset($params['db_records_batchNumber']);
                
                return true;
            }
        } catch (Exception $e) {
            Azure_app_service_migration_Custom_Logger::logError($service_type, 'Table records export exception: ' . $e->getMessage());
            throw new AASM_Export_Exception('Table records export exception:' . $e->getMessage());
        }
        return false;
    }

    // Sends all previously stored db files 
    private static function send_db_files (&$params, $service_type) {
        // Start time
		$start = microtime( true );

        // Initialize completed flag
        $completed = true;

        if (!is_dir(AASM_S2S_DB_LOCATION)) {
            throw new Exception ('Error transferring Database: Could not locate sql files.');
        }

        if (!isset($params['send_db_files'])) {
            Azure_app_service_migration_Custom_Logger::logInfo($service_type, 'Transferring Database files to destination server...', true);
            $params['send_db_files'] = array();
        }

        // Initialize files list parameter
        if (!isset($params['send_db_files']['list'])) {
            $params['send_db_files']['list'] = scandir(AASM_S2S_DB_LOCATION);
        }
        $file_list = $params['send_db_files']['list'];

        // Initialize file start index parameter
        if (!isset($params['send_db_files']['file_index'])) {
            $params['send_db_files']['file_index'] = 0;
        }
        $start_index = $params['send_db_files']['file_index'];

        $file_ind = $start_index;
        while ($file_ind < count($file_list)) {
            // Break and return if time limit exceeded
            if ( ( microtime( true ) - $start ) > 10 ) {
                $completed = false;
                break;
            }
            
            $file_path = AASM_S2S_DB_LOCATION . $file_list[$file_ind];
            if (is_file($file_path)) {
                // send file to destination server
                try {
                    $file_send_result = Azure_app_service_migration_File_Sender::send_file($params, $start, $file_path, substr(AASM_DATABASE_SQL_DIR, strlen(ABSPATH)) . $file_list[$file_ind]);
                } catch (Exception $ex) {
                    throw $ex;
                }

                // Break and return if file send could not be completed
                // File send will continue in next http session
                if (!$file_send_result) {
                    $completed = false;
                    break;
                }

                // Delete db sql file after transferring to destination server
                unlink($file_path);
            }
            $file_ind++;
        }

        if (!$completed) {
            $params['send_db_files']['file_index'] = $file_ind;
            return false;
        }

        unset($params['send_db_files']);
        return true;
    }

    private static function save_db_file($file_path, $file_content, $is_new_file) {
        // Create base directory if doesnt exist
        if (!is_dir(dirname($file_path))) {
            mkdir(dirname($file_path), 0755, true);
        }
        
        if ($is_new_file || !file_exists($file_path)) {
            file_put_contents($file_path, $file_content);
        }
        else {
            $file_content = PHP_EOL . $file_content;
            file_put_contents($file_path, $file_content, FILE_APPEND);
        }
    }

    private static function formatRecordValue($value)
    {
        try {
            if (is_null($value)) {
                return "NULL";
            } elseif (is_int($value) || is_float($value) || is_numeric($value)) {
                return $value;
            } elseif (is_bool($value)) {
                return $value ? 'TRUE' : 'FALSE';
            } elseif (is_object($value) || is_array($value)) {
                return "'" . addslashes(serialize($value)) . "'";
            } elseif (is_string($value)) {
                if (is_numeric($value)) {
                    return $value;
                } elseif (preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
                    return "'" . $value . "'";
                } elseif (preg_match('/^\d{2}:\d{2}:\d{2}$/', $value)) {
                    return "'" . $value . "'";
                } elseif (preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $value)) {
                    return "'" . $value . "'";
                } elseif (is_numeric($value) && (strpos($value, '.') !== false || strpos($value, 'e') !== false)) {
                    return $value;
                } else {
                    return "'" . addslashes($value) . "'";
                }
            } else {
                return "'" . addslashes($value) . "'";
            }
        } catch (Exception $e) {
            Azure_app_service_migration_Custom_Logger::logError(AASM_EXPORT_SERVICE_TYPE, 'Table record format exception: ' . $e->getMessage());
            throw new AASM_Export_Exception('Table record format exception:' . $e->getMessage());
        }
    }
}