<?php
class Azure_app_service_migration_Enumerate_File_Parser {
    public static function add_files_to_zip(&$params, $zip = null, $password = '' ) {
        $service_type = AASM_EXPORT_SERVICE_TYPE;
        
        // Start time
		$start = microtime( true );

        // Initialize completed flag
        $completed = true;

        if (!isset($params['status']['parse_enumerate_file'])) {
            Azure_app_service_migration_Custom_Logger::logInfo($service_type, "Zipping wp-content folder");
            $params['status']['parse_enumerate_file'] = false;
        }

        // Return if zip archive was already created in previous sessions
        if ($params['status']['parse_enumerate_file']) {
            return true;
        }

        // Initialize enumerate file offset
        if (!isset($params['enumerate_file_offset'])) {
            $params['enumerate_file_offset'] = 0;
        }
        $enumerate_file_offset = $params['enumerate_file_offset'];

        try {
            // Open enumerate csv file
            $csvFile = fopen(AASM_ENUMERATE_FILE, 'r');
            if (!$csvFile) {
                throw new Exception('Could not read enumerate csv file: ' . AASM_ENUMERATE_FILE);
            }

            // Seek to the specified offset
            fseek($csvFile , $enumerate_file_offset);

            $current_offset = $enumerate_file_offset;
            while (($row = fgetcsv($csvFile)) !== false) {
                
                $index = $row[0];
                $filePath = $row[1];
                $relativePath = $row[2];
                
                // Add empty directory
                if (is_dir($filePath)) {
                    // add empty directory only for regular export
                    $zip->addEmptyDir($relativePath);
                }
                else if (file_exists($filePath) && is_file($filePath)) {
                    // if regular export then add file to zip
                    // else send file to destination site 
                    $fileContents = file_get_contents($filePath);
                    $zip->addFromString($relativePath, $fileContents);
                }

                $current_offset = ftell($csvFile);

                // Exit if time exceeds 10 seconds
                if ( ( microtime( true ) - $start ) > 10 ) {
                    $completed = false;
                    break;
                }
            }

            if (!$completed) {
                $params['enumerate_file_offset'] = $current_offset;
                return false;
            }

            // Update params
            $params['status']['parse_enumerate_file'] = true;

            // Unset parameters specific to this function
            unset($params['enumerate_file_offset']);

            return true;

        } catch (Exception $ex) {
            Azure_app_service_migration_Custom_Logger::logError(AASM_EXPORT_SERVICE_TYPE, 'Failed to zip wp-content: ' . $e->getMessage());
            throw new AASM_Archive_Exception('Failed to extract wp-content: ' . $e->getMessage());
        }
        
        return false;
    }

    public static function send_files(&$params, $zip = null, $password = '' ) {
        $service_type = AASM_S2S_SERVICE_TYPE;
        
        // Start time
		$start = microtime( true );

        // Initialize completed flag
        $completed = true;

        if (!isset($params['status']['parse_enumerate_file'])) {
            Azure_app_service_migration_Custom_Logger::logInfo($service_type, "Transferring wp-content to destination server");
            $params['status']['parse_enumerate_file'] = false;
        }

        // Return if files were already sent in previous sessions
        if ($params['status']['parse_enumerate_file']) {
            return true;
        }

        // Initialize Chunk count
        if (!isset($params['current_chunk_count'])) {
            $params['current_chunk_count'] = 0;
        }
        $current_chunk_count = $params['current_chunk_count'];

        // Initialize Current file offset
        if (!isset($params['current_file_offset'])) {
            $params['current_file_offset'] = 0;
        }
        $file_offset = $params['current_file_offset'];

        // Initialize enumerate file offset
        if (!isset($params['enumerate_file_offset'])) {
            $params['enumerate_file_offset'] = 0;
        }
        $enumerate_file_offset = $params['enumerate_file_offset'];

        try {
            // Open enumerate csv file
            $csvFile = fopen(AASM_ENUMERATE_FILE, 'r');
            if (!$csvFile) {
                throw new Exception('Could not read enumerate csv file: ' . AASM_ENUMERATE_FILE);
            }

            // Seek to the specified offset
            fseek($csvFile , $enumerate_file_offset);

            $file_list = array();
            $file_count = 0;
            $remaining_size = $params['chunk_size'];
            $current_offset = $enumerate_file_offset;
            while (($row = fgetcsv($csvFile)) !== false) {

                $index = $row[0];
                $filePath = $row[1];
                $relativePath = $row[2];

                if (file_exists($filePath) && is_file($filePath)) {
                    $temp_offset = 0;
                    if ($file_count == 0) {
                        $temp_offset = $current_offset;
                    }

                    $file_content_result = self::get_file_content_from_offset($filePath, $file_offset, $remaining_size);

                    $file_list[] = array(
                        'chunkFileContent' => $file_content_result['file_content'],
                        'isFirstChunk' => $temp_offset === 0,
                        'targetFilePath' => $relativePath,
                        'fileOffset' => $file_offset
                    );

                    $file_count++;
                    $content_read = strlen($file_content_result['file_content']);
                    $file_offset = $file_content_result['is_feof']
                                    ? 0 
                                    : $file_offset + $content_read;
                    $remaining_size = $remaining_size - $content_read;
                    
                    if ($remaining_size <= 0 || $file_count >= $params['chunk_file_count']) {
                        $completed = false;
                        break;
                    }
                }

                $current_offset = ftell($csvFile);
            }

            Azure_app_service_migration_Custom_Logger::logInfo(AASM_S2S_SERVICE_TYPE, 'Transferring Chunk Number : ' . strval($current_chunk_count) . '. File Count: ' . strval($file_count) , true);

            if(!Azure_app_service_migration_File_Sender::send_file_batch($file_list, $params['destination_site_url'], $params['destination_site_token'], $params['server_timeout'])) {
                throw new Exception("Error sending files to destination server");
            }

            if (!$completed) {
                $params['enumerate_file_offset'] = $current_offset;
                $params['current_file_offset'] = $file_offset;
                $params['current_chunk_count'] = $current_chunk_count+1;
                return false;
            }

            // Update params
            $params['status']['parse_enumerate_file'] = true;

            // Unset parameters specific to this function
            unset($params['enumerate_file_offset']);

            return true;

        } catch (Exception $ex) {
            Azure_app_service_migration_Custom_Logger::logError(AASM_S2S_SERVICE_TYPE, 'Failed to transfer wp-content: ' . $ex->getMessage());
            throw new Exception('Failed to extract wp-content: ' . $ex->getMessage());
        }
        
        return false;
    }

    private static function get_file_content_from_offset($file_path, $offset, $content_size) {
        // Initialize file content
        $file_content = false;
        
        // open target file
        $file = fopen($file_path, 'r');
        
        // read file
        if ( !$file ) {
            throw new Exception('Could not read file : ' . $file_path);
        }

        // Seek to offset
        if ( @fseek( $file, $offset, SEEK_SET ) === -1 ) {
			return array(
                'is_feof' => true,
                'file_content' => ''
            );
		}

        $file_content = fread($file, $content_size);
        $is_feof = feof($file);

        // close file
        fclose($file);

        return array(
            'is_feof' => $is_feof,
            'file_content' => $file_content
        );
    }
}