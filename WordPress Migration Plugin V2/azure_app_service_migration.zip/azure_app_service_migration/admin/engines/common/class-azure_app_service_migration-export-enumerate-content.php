<?php
class Azure_app_service_migration_Content_Enumerator {

    public static function enumerate_content(&$params, $service_type) {
		if (!isset($params['status']['enumerate_content'])) {
			$params['status']['enumerate_content'] = false;
			Azure_app_service_migration_Custom_Logger::logInfo($service_type, 'Enumerating Wp-Content folder...');
		}

		// Start time
		$start = microtime( true );

        // Initialize completed flag
        $completed = true;

		// Get folders to be excluded
		$excludedFolders = self::get_excluded_folders($params);

		// Initialize enumerate start index parameter
		if (!isset($params['enumerate_start_index'])) {
			$params['enumerate_start_index'] = 0;
		}
		$enumerate_start_index = $params['enumerate_start_index'];

		// Initialize export file size parameter
        if (!isset($params['export_filesize'])) {
            $params['export_filesize'] = 0;
        }
        $export_filesize = $params['export_filesize'];

		// Initialize export num files parameter
        if (!isset($params['export_num_files'])) {
            $params['export_num_files'] = 0;
        }
        $export_num_files = $params['export_num_files'];

        // Create enumerate file base directory
        $enumerate_file_dir = dirname(AASM_ENUMERATE_FILE);
        if (!is_dir($enumerate_file_dir)) {
            mkdir($enumerate_file_dir, 0755, true);
        }

        // Open in append mode
        $csvFile = fopen(AASM_ENUMERATE_FILE, 'a');

        // Initialize directory iterator
        $directoryIterator = new RecursiveDirectoryIterator(ABSPATH . 'wp-content' . DIRECTORY_SEPARATOR, RecursiveDirectoryIterator::SKIP_DOTS);
        $recursiveIterator = new RecursiveIteratorIterator($directoryIterator, RecursiveIteratorIterator::SELF_FIRST);

        // Initialize indices
        $resumeIndex = $enumerate_start_index;
        $currentIndex = 0;

        foreach ($recursiveIterator as $fileInfo) {
            // break when timeout (50s) is reached
            if ( ( microtime( true ) - $start ) > 50 ) {
                if ($enumerate_start_index > $currentIndex) {
                    throw new Exception('Error enumerating wp-content.');
                }
                $params['export_filesize'] = $export_filesize;
                $params['export_num_files'] = $export_num_files;
                $enumerate_start_index = $currentIndex;
                $completed = false;
                break;
            }

            if ($fileInfo->isFile() || $fileInfo->isDir()) {
                if ($currentIndex >= $resumeIndex) {
                    $filePath = $fileInfo->getPathname();

					// Initialize exclude file flag
                    $excludeFile = false;
                    foreach($excludedFolders as $excludedFolder) {
                        if (str_starts_with($filePath, AASM_Common_Utils::replace_forward_slash_with_directory_separator(ABSPATH . 
                                                                                                                        'wp-content' . 
                                                                                                                        DIRECTORY_SEPARATOR . 
                                                                                                                        $excludedFolder))) {
                            $excludeFile = true;
                        }
                    }

                    // Add file to csv if it is not part of excluded folders
                    if (!$excludeFile) {
                        $relativePath = $filePath;
                        $rootDirPrefix = ABSPATH;
                        if (strpos($filePath, $rootDirPrefix) === 0) {
                            $relativePath = substr($filePath, strlen($rootDirPrefix));
                        }
                        fputcsv($csvFile, [$currentIndex, $filePath, $relativePath]);

                        $export_num_files++;
                        $export_filesize += filesize($filePath);
                    }
                }
            }
            $currentIndex++;
        }

        fclose($csvFile);
        return array(
            'completed' => $completed,
            'enumerate_start_index' => $enumerate_start_index,
        );
    }

	private static function get_excluded_folders($params) {
		$dontexptsmedialibrary = isset($params['dontexptsmedialibrary']) ? $params['dontexptsmedialibrary'] : null;
		$dontexptsthems = isset($params['dontexptsthems']) ? $params['dontexptsthems'] : null;
		$dontexptmustuseplugins = isset($params['dontexptpostrevisions']) ? $params['dontexptpostrevisions'] : null;
		$dontexptplugins = isset($params['dontexptplugins']) ? $params['dontexptplugins'] : null;

		$excludedFolders = [];
        if ($dontexptsmedialibrary) {
            $excludedFolders[] = 'uploads';
        }
        if ($dontexptsthems) {
            $excludedFolders[] = 'themes';
        }
        if ($dontexptmustuseplugins) {
            $excludedFolders[] = 'mu-plugins';
        }
        if ($dontexptplugins) {
            $excludedFolders[] = 'plugins';
        }

        // Exclude AASM plugin from export
        $excludedFolders[] = AASM_PLUGIN_RELATIVE_PATH;
        $excludedFolders[] = AASM_DEBUG_LOG_PATH;
        $excludedFolders[] = basename(AASM_W3TC_ADVANCED_CACHE_PATH);
        $excludedFolders[] = basename(AASM_W3TC_OBJECT_CACHE_PATH);
        $excludedFolders[] = basename(AASM_W3TC_DB_PATH);
        
        return $excludedFolders;
	}
}