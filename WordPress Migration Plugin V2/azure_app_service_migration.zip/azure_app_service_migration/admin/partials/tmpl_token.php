<style>
    button img {
        outline: none;
    }
    
    button:focus {
        outline: none;
    }
</style>

<div class="col-md-11 mt-5">
    <div class="shadow p-3 mb-5 bg-body rounded">
        <div class="shadow-sm p-4 mb-4 bg-white boderbottom">
            <h5>Token</h5>
        </div>
        <div>
            <?php
                // define fluent UI src url
                $wp_root_url = get_home_url();
                $src = $wp_root_url . "/wp-content/plugins/azure_app_service_migration/assets/node_modules/@fluentui/web-components/dist/web-components.js";
                $clipboard_img_src = $wp_root_url . "/wp-content/plugins/azure_app_service_migration/assets/images/copy_icon.jpg";
                // Get token
                $token = "-";

                $fileContents = file_get_contents(AASM_AUTH_TOKEN_FILE_PATH);
                if ($fileContents !== false) {
                    $token = $fileContents;
                }
            ?>
        </div>
        <div class="token-text-container" style="margin-left:2em;">
            <fluent-text-field name="token" id="token_token" appearance="filled" value="<?php echo $token; ?>" readonly onclick="this.select();">
            </fluent-text-field>
            <button onclick="copyToClipboard()" >
                <img src="<?php echo $clipboard_img_src ?>" width="30" height="30">
            </button>
        </div>
        <br>
        <div>
            <fluent-button class="generateToken" name="token_generateToken" id="token_generateToken" appearance="accent">
                Generate Token
            </fluent-button>
        </div>
        <br>
        
        <div class="alert-container">
            <div class="alert-box">
                <p id="token_alert-message"></p>
                <button onclick="hideAlert()">OK</button>
            </div>
        </div>
    </div>
</div>

<script type="module" src="<?php echo esc_url($src); ?>"></script>

<script type="text/javascript" language="javascript">
    $(document).ready(function() {
    });

    function copyToClipboard() {
        var textField = document.getElementById("token_token");
        textField.select(); // Selects the text field contents
        document.execCommand("copy"); // Copies the selected text to clipboard
    }
    
    var jsonWebTokenValue = document.getElementById('token_token');

    var ajaxUrl = azure_app_service_migration.ajaxurl;

    // Processing event on button click
	$("#token_generateToken").click(function () {
		$('#s2s_downloadLink').hide();
		$(this).prop("disabled", true).text("Generating Token...");

		var postdata = "&action=aasm_generate_token";

		$.ajax({
			url: ajaxUrl,
			type: "POST",
			data: postdata,
			dataType: "json",
			success: function (data) {
                jsonWebTokenValue.value = data.token;
                $("#token_generateToken").prop("disabled", false).text("Generate Token");
			},
			error: function (jqXHR, textStatus, errorThrown) {
				token_showAlert("An error occurred while generating token.");
			}
		});
	});

    function token_showAlert(message) {
		var alertBox = document.querySelector('.alert-container');
		var alertMessage = document.getElementById('token_alert-message');
	  
		alertMessage.textContent = message;
		alertBox.style.visibility = 'visible';
	}

    function hideAlert() {
		var alertBox = document.querySelector('.alert-container');
		alertBox.style.visibility = 'hidden';
	}  
</script>
