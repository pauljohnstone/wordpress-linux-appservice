<style>
        .button-progress-container {
            display: flex;
            align-items: center;
        }
        .fluent-progress-ring {
            margin-left: 10px;
        }
        #s2s_dialog {
            position: fixed;
            top: 35%;
            left: 30%;
            transform: translate(-50%, -50%);
            width: 400px;
            height: 450px;
            overflow: auto; /* Adds scrollbars if content overflows */
        }
</style>
<div class="col-md-11 mt-5">
    <div class="shadow p-3 mb-5 bg-body rounded">
        <div class="shadow-sm p-4 mb-4 bg-white boderbottom">
            <h5>Server to Server Migration</h5>
        </div>
        <form id="s2s_frm-chkbox-data">
            <ul>
                <li>
                    <fluent-checkbox class="s2sexportdata" name="dontexptpostrevisions" id="s2s_dontexptpostrevisions" value="dontexptpostrevisions">
                        Do not export post revisions
                    </fluent-checkbox>
                </li>
                <li>
                    <fluent-checkbox class="s2sexportdata" name="dontexptsmedialibrary" id="s2s_dontexptsmedialibrary" value="dontexptsmedialibrary">
                        Do not export media library (files)
                    </fluent-checkbox>
                </li>
                <li>
                    <fluent-checkbox class="s2sexportdata" name="dontexptsthems" id="s2s_dontexptsthems" value="dontexptsthems">
                        Do not export themes (files)
                    </fluent-checkbox>
                </li>
                <li>
                    <fluent-checkbox class="s2sexportdata" name="dontexptmustuseplugs" id="s2s_dontexptmustuseplugs" value="dontexptmustuseplugs">
                        Do not export must-use plugins (files)
                    </fluent-checkbox>
                </li>
                <li>
                    <fluent-checkbox class="s2sexportdata" name="dontexptplugins" id="s2s_dontexptplugins" value="dontexptplugins">
                        Do not export plugins (files)
                    </fluent-checkbox>
                </li>
                <li>
                    <fluent-checkbox class="s2sexportdata" name="donotdbsql" id="s2s_dbsql" value="donotdbsql" style="display: none;">
                        Do not Export database (SQL)
                    </fluent-checkbox>
                </li>
            </ul>
            <div style="margin-left:2em;">
                <fluent-text-field name="destinationSite" id="s2s_destinationSite" appearance="filled" placeholder="https://mytestapp.com/" style="width: 200px;">
                    Destination Site URL
                </fluent-text-field>                
            </div>
            <br>
            <div style="margin-left:2em;">
                <fluent-text-field name="s2s_token" id="s2s_token" appearance="filled" style="width: 200px;">
                    Destination Site Token
                </fluent-text-field>                
            </div>
            <br>  
            <div id="advanced_placeholder" style="margin-left:2em; font-weight: bold; cursor: pointer;">
                ▶Advanced
            </div>
            <div id="advanced_section" style="display: none; margin-left:2em;">
                <fluent-text-field name="s2s_chunkSize" id="s2s_chunkSize" value="5000" appearance="filled" style="width: 200px;">
                    Data Transfer Chunk Size (KB)
                </fluent-text-field>
                <fluent-text-field name="s2s_serverTimeout" id="s2s_serverTimeout" value="60" appearance="filled" style="width: 200px;">
                    Server timeout (Seconds)
                </fluent-text-field>
            </div>
            <br>

            <div class="button-progress-container">
                <fluent-button class="generatefile" name="generatefile" id="s2s_generatefile" appearance="accent">
                    Migrate
                </fluent-button>

                <fluent-button class="cancel" name="cancel" id="s2s_cancel" appearance="accent" style="display: none;">
                    Cancel Migration
                </fluent-button>

                <fluent-progress-ring id="progressRing" class="fluent-progress-ring" hidden></fluent-progress-ring>
            </div>
            <dialog id="s2s_dialog"  trap-focus modal>
                <div style="margin: 20px;">
                    <div class="note">
                        Note that during the migration process:
                        <ul>
                            <li>1. The source site and the destination site will be under maintenance mode. Users will not be able to access these sites.</li>
                            <li>2. If you leave this page during migration, the migration process will continue in the backend. Please do not restart the migration until the migration is successfully completed.</li>
                        </ul>
                    </div>
                    <label>
                        <input type="checkbox" id="s2s_acknowledge"> I understand the scenarios mentioned above and I am sure I want to continue.
                    </label>
                    <br>
                    <fluent-button id="s2s_dialog_migrate" appearance="accent" tabindex="0" onclick="s2s_startMigration()" disabled>Migrate</fluent-button>
                    <fluent-button id="s2s_dialog_cancel" appearance="accent" tabindex="1" onclick="closeDialog()">Cancel</dluent-button>
                </div>
            </dialog>
            <br>
        </form>
        <div id="s2s_exportdownloadfile">
            <?php
            $wp_root_url = get_home_url();
            $src = $wp_root_url . "/wp-content/plugins/azure_app_service_migration/assets/node_modules/@fluentui/web-components/dist/web-components.js";
            ?>
            <div class="overlay"></div>
        </div>
        
        <div class="alert-container">
            <div class="alert-box">
                <p id="s2s_alert-message"></p>
                <button onclick="hideAlert()">OK</button>
            </div>
        </div>
    </div>
</div>

<script type="module" src="<?php echo esc_url($src); ?>"></script>

<script type="text/javascript" language="javascript">
    $(document).ready(function() {
    });

    // Function to show the dialog
    function s2s_showDialog() {
        // Reset checkbox value
        document.getElementById('s2s_acknowledge').checked = false;
        document.getElementById('s2s_dialog_migrate').disabled = true;

        var dialog = document.getElementById('s2s_dialog');
        dialog.showModal();
    }

    // Function to close the dialog
    function closeDialog() {
        var dialog = document.getElementById('s2s_dialog');
        dialog.close();
    }

    function toggleProgressRing() {
        var progressRing = document.getElementById("progressRing");
        if (progressRing.hasAttribute("hidden")) {
            // Show the progress ring if it's hidden
            progressRing.removeAttribute("hidden");
        } else {
            // Hide the progress ring if it's shown
            progressRing.setAttribute("hidden", "");
        }
    }

    function s2s_downloadLogFile() {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', '<?php echo get_home_url(); ?>/wp-content/plugins/azure_app_service_migration/Logs/s2s_log.txt', true);
        xhr.responseType = 'blob';

        xhr.onload = function() {
            if (xhr.status === 200) {
                var link = document.createElement('a');
                link.href = window.URL.createObjectURL(xhr.response);
                link.download = 's2s.txt';
                link.click();
            }
        };

        xhr.send();
    }

    document.getElementById('advanced_placeholder').addEventListener('click', function() {
        var advancedSection = document.getElementById('advanced_section');
        advancedSection.style.display = (advancedSection.style.display === 'none' || advancedSection.style.display === '') ? 'block' : 'none';
    });
    
    document.getElementById('s2s_acknowledge').addEventListener('change', function() {
        var migrateButton = document.getElementById('s2s_dialog_migrate');
        if (this.checked) {
            migrateButton.disabled = false;
        } else {
            migrateButton.disabled = true;
        }
    });

    var sourceSiteAjaxurl = azure_app_service_migration.ajaxurl;
    var destinationSiteAjaxurl = $("#s2s_destinationSite").val() + "wp-admin/admin-ajax.php";

    function s2s_startMigration() {
        closeDialog();
        showMigrationInProgress();

		var postdata = $("#s2s_frm-chkbox-data").serialize();
		postdata += "&action=aasm_s2s";
		postdata += "&is_first_request=true";
        postdata += "&destination_site_url=" + $('#s2s_destinationSite').val();
        postdata += "&destination_site_token=" + $('#s2s_token').val();
        postdata += "&server_timeout=" + parseInt($('#s2s_serverTimeout').val());
        postdata += "&chunk_size=" + parseInt($('#s2s_chunkSize').val());
        
		$.ajax({
			url: sourceSiteAjaxurl,
			type: "POST",
			data: postdata,
			dataType: "json",
			success: function (data) {
				console.log(data);
				//start getting export status 
				s2s_getStatus(0, sourceSiteAjaxurl, 'aasm_s2s_status');
			},
			error: function (jqXHR, textStatus, errorThrown) {
			    showMigrationNotInProgress();
                $("#s2s_generatefile").prop("disabled", false).text("Migrate");
				s2s_showAlert("An error occurred while processing the request.");
			},
			complete: function () {
			}
		});
    }

    // Processing event on button click
	$("#s2s_generatefile").click(function () {
		s2s_showDialog();
	});

    $("#s2s_cancel").click(function () {
        $(this).prop("disabled", true);

		$.ajax({
			url: sourceSiteAjaxurl,
			type: "POST",
			data: {
                action: "aasm_s2s_cancel"
            },
			dataType: "json",
			success: function (data) {
                $(this).prop("disabled", false);
                showMigrationNotInProgress();
			},
			error: function (jqXHR, textStatus, errorThrown) {
                $(this).prop("disabled", false);
				s2s_showAlert("An error occurred while cancelling the migration.");
			},
			complete: function () {
                $(this).prop("disabled", false);
			}
		});
	});

    function s2s_getStatus(retryCount, ajaxurl, action) {
		// Set max retry count for getting status from server
		maxRetryCount = 10;

		$.ajax({
            url: ajaxurl,
            type: 'POST',
            dataType: 'json',
            data: {
                action: action, // Adjust the server-side action name
            },
            success: function(response) {
                if (response.status === 'done' ) {
                    if (ajaxurl === destinationSiteAjaxurl) {
                        showMigrationNotInProgress();
                        s2s_showAlert("Server to Server Migration Completed!");
                    }
                    else {
                        setTimeout(function() {
                            s2s_getStatus(0, destinationSiteAjaxurl, 'aasm_import_status');
                        },2000);
                    }
                }
                else if (response.status === 'exception' || response.status === 'error') {
                    showMigrationNotInProgress();
                    $("#s2s_generatefile").prop("disabled", false).text("Migrate");
                    s2s_showAlert("Error: " + response.message);
                    toggleProgressRing();
                }
                else {
                    setTimeout(function() {
                        s2s_getStatus(0, ajaxurl, action);
                    },2000);
                }
            },
            error: function(xhr, status, error) {
                // Retry the updateStatus call if the maximum number of retries is not reached
                if (retryCount < maxRetryCount) {
                    s2s_getStatus(retryCount+1, ajaxurl, action);
                }
                else {
                    showMigrationNotInProgress();
                }
            }
		});
	}

    function showMigrationInProgress() {
        var cancelButton = document.getElementById('s2s_cancel');
        var generateButton = document.getElementById('s2s_generatefile');
		var progressRing = document.getElementById('progressRing');

        $("#s2s_cancel").prop("disabled", false);

        generateButton.style.display = 'none';
        cancelButton.style.display = 'block';
        progressRing.style.display = 'block';
    }

    function showMigrationNotInProgress() {
        var cancelButton = document.getElementById('s2s_cancel');
        var generateButton = document.getElementById('s2s_generatefile');
		var progressRing = document.getElementById('progressRing');

        generateButton.style.display = 'block';
        cancelButton.style.display = 'none';
        progressRing.style.display = 'none';
    }

    function s2s_showAlert(message) {
		var alertBox = document.querySelector('.alert-container');
		var alertMessage = document.getElementById('s2s_alert-message');

		alertMessage.textContent = message;
		alertBox.style.visibility = 'visible';
	}

    function hideAlert() {
		var alertBox = document.querySelector('.alert-container');
		alertBox.style.visibility = 'hidden';
	}  
</script>
