<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://wordpress.org/plugins/azure-app-service-migration/
 * @since      1.0.0
 *
 * @package    Azure_app_service_migration
 * @subpackage Azure_app_service_migration/admin/partials
 */
?>