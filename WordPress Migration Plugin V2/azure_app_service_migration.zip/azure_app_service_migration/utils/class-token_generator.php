<?php
class Azure_app_service_migration_Server_Token_Generator {

    public static function generate_token() {
        if (!is_dir(dirname(AASM_AUTH_TOKEN_FILE_PATH))) {
			mkdir(dirname(AASM_AUTH_TOKEN_FILE_PATH), 0755, true);
		}

        $token = self::generateRandomString();
		file_put_contents(AASM_AUTH_TOKEN_FILE_PATH, $token . PHP_EOL . microtime( true ));

		$response = array( 'token' => $token );
		echo json_encode($response);

		wp_die();
    }

	private static function generateRandomString() {
		$length = 64;
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$randomString = '';
		
		for ($i = 0; $i < $length; $i++) {
			$randomString .= $characters[rand(0, strlen($characters) - 1)];
		}
		
		return $randomString;
	}
}