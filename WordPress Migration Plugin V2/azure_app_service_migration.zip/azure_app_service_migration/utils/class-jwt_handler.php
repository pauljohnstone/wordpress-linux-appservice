<?php
use Firebase\JWT\JWT;
class Azure_app_service_migration_Server_Jwt_Handler {

    public static function encode($key, $data) {
        // Create a JWT token
		return JWT::encode($data, $key, 'HS256');
    }

	public static function decode($jwtToken, $key) {
        // Decode and verify the JWT token
        try {
            $decodedToken = (array) JWT::decode($jwtToken, $key, array('HS256'));
            // Check if decoding was successful
            if ($decodedToken) {
                return $decodedToken;
            } else {
				return false;
            }
        } catch (Exception $e) {
            // Handle token verification failure
            return false;
        }
	}
}